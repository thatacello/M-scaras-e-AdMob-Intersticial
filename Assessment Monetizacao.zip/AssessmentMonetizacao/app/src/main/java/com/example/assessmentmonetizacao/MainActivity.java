package com.example.assessmentmonetizacao;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Context;
import android.os.Bundle;
import android.renderscript.Sampler;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.ads.AdRequest;
import com.google.android.gms.ads.InterstitialAd;
import com.google.android.gms.ads.MobileAds;
import com.google.android.gms.ads.initialization.InitializationStatus;
import com.google.android.gms.ads.initialization.OnInitializationCompleteListener;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.OutputStreamWriter;

public class MainActivity extends AppCompatActivity {
    
    private EditText edtNome;
    private EditText edtEmail;
    private EditText edtSenha;
    private EditText edtConfirmaSenha;
    private EditText edtCPF;

    private TextView textView;
    
    private Button btnSalvar;

    private InterstitialAd mInterstitialAd;
    
    String NOME_ARQUIVO = "cadastros.txt";

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        
        edtNome = findViewById(R.id.edtNome);
        edtEmail = findViewById(R.id.edtEmail);
        edtSenha = findViewById(R.id.edtSenha);
        edtConfirmaSenha = findViewById(R.id.edtConfirmaSenha);
        edtCPF = findViewById(R.id.edtCPF);
        
        btnSalvar = findViewById(R.id.btnSalvar);

        edtCPF.addTextChangedListener(Mascaras.mask(edtCPF, Mascaras.FORMAT_CPF));

        MobileAds.initialize(this, new OnInitializationCompleteListener() {
            @Override
            public void onInitializationComplete(InitializationStatus initializationStatus) {
            }
        });
        mInterstitialAd = new InterstitialAd(this);
        mInterstitialAd.setAdUnitId("ca-app-pub-7927458969649246/6619452587");
        mInterstitialAd.loadAd(new AdRequest.Builder().build());
        
        btnSalvar.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                
                if (edtNome.getText().toString().isEmpty() || edtEmail.getText().toString().isEmpty()
                || edtSenha.getText().toString().isEmpty() || edtConfirmaSenha.getText().toString().isEmpty()
                || edtCPF.getText().toString().isEmpty()){
                    Toast.makeText(MainActivity.this, "Todos os campos devem ser preenchidos!",
                            Toast.LENGTH_SHORT).show();
                    
                }else if (!edtSenha.getText().toString().equals(edtConfirmaSenha.getText().toString())){
                    edtConfirmaSenha.requestFocus();
                    Toast.makeText(MainActivity.this, "As senhas não correspondem!",
                            Toast.LENGTH_SHORT).show();
                    
                }else if (!isEmailValido(edtEmail.getText().toString())){
                    edtEmail.requestFocus();
                    Toast.makeText(MainActivity.this, "E-mail inválido!",
                            Toast.LENGTH_SHORT).show();

                }else if (!validarNome(edtNome.getText().toString())){
                    edtNome.requestFocus();
                    Toast.makeText(MainActivity.this, "Nome contém caracteres inválidos!",
                            Toast.LENGTH_SHORT).show();

                }else {

                    String nomeDig = edtNome.getText().toString();
                    String emailDig = edtEmail.getText().toString();
                    String senhaDig = edtSenha.getText().toString();
                    String cpfDig = edtCPF.getText().toString();

                    gravarCadastro(nomeDig, emailDig, senhaDig, cpfDig);
                    
                }

                if (mInterstitialAd.isLoaded()) {
                    mInterstitialAd.show();
                } else {
                    Log.d("TAG", "The interstitial wasn't loaded yet.");
                }

            }
        });

    }

    private boolean isEmailValido (String email){
        boolean resultado = (Patterns.EMAIL_ADDRESS.matcher(email).matches());
        return resultado;
    }

    private boolean validarNome (String nome){
        boolean nomes = nome.matches("[a-zA-Z\\s]*");
        return nomes;
    }

    private void gravarCadastro (String nome, String email, String senha, String cpf){

        try {
            FileOutputStream fos = openFileOutput(NOME_ARQUIVO, Context.MODE_PRIVATE);
            fos.write(nome.getBytes());
            fos.write(email.getBytes());
            fos.write(senha.getBytes());
            fos.write(cpf.getBytes());
            fos.close();
            Toast.makeText(this, "Cadastro salvo com sucesso!", Toast.LENGTH_SHORT).show();

        } catch (FileNotFoundException e) {
            e.printStackTrace();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
    
}
